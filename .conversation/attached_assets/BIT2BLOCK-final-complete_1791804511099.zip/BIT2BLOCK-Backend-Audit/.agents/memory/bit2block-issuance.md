---
name: BIT2BLOCK issuance
description: Canonical B2B block reward, halving interval, and maximum supply.
---

BIT2BLOCK's authoritative issuance rules are 3,200 B2B per block, halving every 2,160 blocks, with a maximum supply of 21,000,000 B2B.

**Why:** The user explicitly confirmed these product rules from the current backend and asked that repairs preserve the economics.

**How to apply:** Keep the same reward schedule and cap in mining generation, supply metrics, and related API/UI calculations unless the user explicitly changes them.
