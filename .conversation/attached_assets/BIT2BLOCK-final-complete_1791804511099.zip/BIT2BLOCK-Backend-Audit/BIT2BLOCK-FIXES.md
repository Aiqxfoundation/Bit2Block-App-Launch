# BIT2BLOCK mining integrity fixes

## Canonical rules

- Stored hashrate is in MH/s units: `0.10` means `100 KH/s`. UI formatting now uses the same shared formatter.
- New users own the free `100 KH/s` starter amount from registration; mining activation only enables rewards. Legacy accounts are reconciled by the idempotent `0006_free_starter_hashrate.sql` migration.
- Purchases and their referral rewards are committed in one transaction. Each paid purchase uses one canonical referral flow (10% USDT commission plus 10% of purchased hashrate); purchase milestones no longer create referral codes and the duplicate legacy 5% hashrate bonus was removed.
- `mining_blocks` is the source of truth for block height. The scheduler locks generation, snapshots eligible locked power, caps issuance at 21,000,000 B2B, and uses 3,200 B2B per block with the reward period changing after every 2,160 blocks. No reward is issued to nobody: a block with zero eligible power records a zero reward.
- `unclaimed_blocks` is the payout ledger. Claims lock the user row and atomically mark rows claimed and credit the balance. Legacy claim URLs now settle this same ledger; server startup does not auto-credit pending rewards.
- The public user serializer strips access keys, security PINs, 2FA secrets, and registration IPs. Transfers, deposit approvals, and withdrawal approvals are transactional. Pending deposits/withdrawals cannot be approved or rejected twice, and BTC withdrawals use the BTC balance instead of accidentally touching USDT/B2B balances.
- The global miner list is paginated and referral/pending-reward totals are aggregated in SQL; global user count no longer loads every user row into memory.
- Global block hashrate columns use wider numeric precision so network totals do not overflow individual-user hashrate capacity. The 24-pending-block suspension check uses the actual pending ledger count. Suspended, frozen, banned, and inactive accounts do not contribute eligible hashrate.
- Global statistics and recent block history come from persisted backend data. Client-generated nonce/hash animations and fabricated dashboard stats were removed or relabeled as visual/demo-only.
- Unused duplicate `api-server` and `mockup-sandbox` workspace packages were removed. The frontend no longer supports the alternate `VITE_API_URL`/Go-backend override; the active application backend is `artifacts/bit2block/server`.

## Database update

The schema now declares unique indexes for block height and per-user block rows. Before applying the schema update, check for existing duplicates; unique-index creation will fail if these queries return rows:

```sql
SELECT block_number, COUNT(*) FROM mining_blocks GROUP BY block_number HAVING COUNT(*) > 1;
SELECT user_id, block_number, COUNT(*) FROM unclaimed_blocks GROUP BY user_id, block_number HAVING COUNT(*) > 1;
SELECT user_id, block_number, COUNT(*) FROM mining_history GROUP BY user_id, block_number HAVING COUNT(*) > 1;
```

After reconciling any duplicates and taking a database backup, run the app's normal Drizzle schema push from `artifacts/bit2block` (`pnpm run db:push`). The SQL migration is also included as `migrations/0005_mining_integrity_constraints.sql` for manual migration workflows; it also reconciles legacy BTC withdrawals that were debited at submission and, on approval, incorrectly debited B2B. It refunds rejected requests' BTC and restores the accidental B2B debit for completed requests. Apply that SQL only once after the duplicate checks and a database backup. Legacy *completed BTC deposits* may have been credited to USDT by the previous implementation; review those account balances manually before reclassifying them, because some of the wrongly credited USDT may already have been spent.

## Verification limits

All 115 TypeScript/TSX source files passed a syntax transpilation check. A full typecheck/build and live PostgreSQL integration tests could not be run in this environment because workspace dependencies (including `@types/node` and `vite/client`) are not installed and package installation was unavailable offline. Run the full workspace typecheck/build and database tests before deploying.

**Important:** this backend creates scheduled database ledger blocks and SHA-256 identifiers; it is not proof-of-work mining and does not create on-chain blocks. No UI should describe these identifiers as on-chain transactions.

## Additional final-pass fixes

- The free starter `100 KH/s` is now owned from registration (`0.10` internal MH/s). Starting mining activates it and cannot grant it twice. Existing users who have not started mining receive the starter grant through the idempotent `0006_free_starter_hashrate.sql` migration; already-started accounts are only marked as granted.
- Admin default-miner filters now use the canonical `0.10 MH/s` value instead of the old erroneous `100` value. Admin active/inactive miner lists also account for suspended status.
- Referral hashrate display no longer multiplies an already-canonical stored value by 1,000 a second time.
- Claiming the final pending block only resumes mining if the account was suspended by the pending-block limit. A manual/admin pause is preserved; claim response messages now report actual resumption.
- Admin hashrate edits update base power and next-block power together, preserving `owned = base + referral bonus` and validating non-negative supported ranges.
- BTC staking uses one row-locked transaction for the stake record and BTC debit; the backend now converts stored MH/s to displayed GH/s and honors the UI's `useHashrate` choice. APR is persisted alongside the reward calculation.
- Daily BTC staking settlement uses a transaction-scoped advisory lock and same-UTC-day idempotency. Expired stakes return their principal and transition to `completed` in the same transaction; the settlement job runs hourly so unlocks are not delayed until midnight.
- Referral codes use cryptographically random hexadecimal values, collision retries, and an atomic counter update.

## Final-pass deployment notes

Back up PostgreSQL first. Run the normal Drizzle schema push so the `free_starter_granted` column exists, then apply `migrations/0005_mining_integrity_constraints.sql` and `migrations/0006_free_starter_hashrate.sql` once, in that order, after resolving the duplicate rows described above. The 0006 update is idempotent. Reconcile old `unclaimed_balance` values against the `unclaimed_blocks` ledger before allowing legacy claims, and manually review legacy BTC deposit/withdrawal records as noted above.

The latest source pass was checked with TypeScript's transpilation parser: all 115 TS/TSX files passed syntax transpilation. Full typecheck/build and live PostgreSQL/concurrency tests remain unverified because the environment lacks the workspace's installed dependencies and a connected database. Do not treat this ZIP as deployment-certified until those tests pass.
