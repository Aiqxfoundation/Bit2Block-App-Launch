# BIT2BLOCK

BIT2BLOCK is the single active application package. It contains the React client, Express API, PostgreSQL/Drizzle data layer, and scheduled database-backed mining ledger.

## Run & Operate

- `pnpm --filter @workspace/bit2block run dev` — start the application in development
- `pnpm --filter @workspace/bit2block run typecheck` — typecheck the application package
- `pnpm --filter @workspace/bit2block run build` — build the client and Express server
- `pnpm --filter @workspace/bit2block run db:push` — apply Drizzle schema changes (back up production data first)
- Required environment: `DATABASE_URL` (PostgreSQL), plus the app's configured session/security secrets.

## Stack

- React + Vite frontend
- Express API in `artifacts/bit2block/server`
- PostgreSQL + Drizzle ORM
- Shared schema in `artifacts/bit2block/shared/schema.ts`

The scheduled mining subsystem creates database ledger blocks; it is not proof-of-work or on-chain mining.
